<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="<?= images ?>/favicon.ico" type="image/x-icon">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Pridi:wght@200;300;400;500;600;700&family=Quicksand:wght@300..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= css ?>/style.css">
    <link rel="stylesheet" href="<?= css ?>/login.css">
</head>
<style>
    .container{
        width: 100%;
        min-height: 100dvh;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 10px;
    }
</style>
<body>
    <div class="container">
        <h2>Sorry, Currently We cannot given access to create an account from website</h2>
        <p>if you want to create an account install mobile version, <a href="https://github.com/wldnz/perpustakaanxyz">Install here...</a></p>
        <a href="<?= base_url("/") ?>">Back To Dashboard?</a>
    </div>
</body>
</html>